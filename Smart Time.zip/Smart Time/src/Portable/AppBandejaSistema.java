
package Portable;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
/**
 *
 * @author felipe.dasilva
 */
public class AppBandejaSistema {

    public static void main(String[] args) {
        // Verificar se o sistema suporta a bandeja
        if (!SystemTray.isSupported()) {
            System.out.println("Bandeja do sistema não suportada.");
            return;
        }
        
        // Criar o ícone de bandeja
        SystemTray systemTray = SystemTray.getSystemTray();
        TrayIcon trayIcon = new TrayIcon(Toolkit.getDefaultToolkit().getImage(System.getProperty("user.home") + "\\Documents\\TimerIS\\play48x48.png"));
        
        // Adicionar um menu para o ícone
        PopupMenu popup = new PopupMenu();
        MenuItem exitItem = new MenuItem("Sair");
        
        exitItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.exit(0);  // Fechar o aplicativo quando o item "Sair" for clicado
            }
        });

        popup.add(exitItem);
        trayIcon.setPopupMenu(popup);
        
        // Adicionar o ícone à bandeja
        try {
            systemTray.add(trayIcon);
        } catch (AWTException e) {
            e.printStackTrace();
        }
        
        // Deixar o aplicativo rodando em segundo plano
        trayIcon.displayMessage("Aplicativo", "O aplicativo está rodando em segundo plano!", TrayIcon.MessageType.INFO);
    }
}
