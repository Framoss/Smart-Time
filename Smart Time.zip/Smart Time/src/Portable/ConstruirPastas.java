package Portable;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Base64;
import java.util.List;
import javax.swing.JOptionPane;

public class ConstruirPastas {

    private String vPath;
    private String play48;
    private String stop48;
    private String icone;
    private String iconeG;

    private String caminhoBanco;
    private String nomeArquivo = "476387383";

    public ConstruirPastas() {
        this.vPath = "C:\\TimerIS";
        this.play48 = "iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAACXBIWXMAAAsTAAALEwEAmpwYAAACP0lEQVRoge2YS2hTQRSGz7kzNO+bakxjkiaNTa00NIIVBJv6qIqoRYlBa1p0XRRBunMj6tJVwQciXSgupeBK3IjaVRFcFLQU7aLUgqLYgoqFislxbvQuKglpo2QYmA/+VXKH/wvDmTsB0Gg0Go1Go5ECl12gZjr3RYdyw7s/p/qCr70tkJPdZ81093c8G10cosF5Tpmb7EtwBz5p2ADtsnutmkw+NX59YbAkYCU/y6nzgvGxsQPGxMem7H5V+VvATm6SU9tp443ZalwSXzNk96xIJQE7Bx+yHxt34StfCxyR3bUs1QTsdN9gC4EufO4wISm78wpWK2Dl1Ayn1HljvjGNd8SjLtndS6xFwE52ghfjfTjjbYOLYglUTsDOgTG2FN6LE84wZJQUKOUdp67LbHFdGp6K5ULqCfzJyWkxds8Ys/7NeAvqOXb/l4Cd2GGjYG7C+0oK7LnLqMEE8ibxnlICR8cZRXqRXCFc8iVwFFTZQiemxLlwziDHevzpjcOkWK6pbsX/RWBgjtPOEUauJix64jAnxmhP3YvXKrD/ASN/O5I7DF89MbgKqhxk2RecElmxz4O47Emg9artlFrcpppA/1tO6WGDnAEsiF98yuGHVtmdV1BRQJywPbeZ2CpYdEfhky8Cx2R3LUs5gUOPGAW2iX0ewW+eKF4DVS40x19ySg4Y1nRZFtvlMahwpbQu9SMf8rT9ijXPoeBuhmmlLvVbe2NnQ1vM755meC+Sl92nVtT9Y0uj0Wg0Go3mN78AQDJ5AHjEfisAAAAASUVORK5CYII=";
        this.stop48 = "iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAACXBIWXMAAAsTAAALEwEAmpwYAAAA2ElEQVRoge2YvQqCUBiGz4FD4SAcoSVdJLuD2sTRIKJF8BaavRHdu4GGGqoLqsWlWaQfCuxza87DN9T7wLMe3sftUwgAAAAAAPANHjkxpMe6fBEEmzxJ6l0c37ZRdO3qyversVJHrv1ukab1JQyb0raNeCIdKZ/09pAjYHrIsleptbGA1r6UTfs2X4DB8QhAAAIQgAAEIAABCEAAAv434Ez2hGALcHM6KUvHMRawtizWk1LM6ahfal2lSt27OlPqMaDxIyn3LOM/cIW53yo8Xx4AAAAA4Md4A4GLuD5jsYX1AAAAAElFTkSuQmCC";
        this.icone = "iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAACXBIWXMAAAsTAAALEwEAmpwYAAABB0lEQVQ4jWNgwAIcD5/QtztwshwZ2xw6rodNLVZgf+DkHPuDJ/8jY7sDJ2YTbQDZwNQ/q83ML+unmX/2f6wYLJfVgtMAFM1+2XdN/bJmgrF/1j2EQVk/cBsAVQTUMM/cN0/cPCA7DYx9k8WBBs6HyeM3AGgzSDPYVr+sSRAMEksWh7nE1C87A6cBQMkZQGemQ1yS3WDil+MC9MYlIE4Fis3C6wqIAVkzQc6Gsi8BDSmHG+CXNZugATAvgGik0L+D7AUgvxBvIIICDKwBaCsIgwPRP2sB4UBEikaobSA/zwKGy30iozGrhXBCym7GaQDVACjjYGSmgydmEW0AKOvaHzzRgYxxZWcAJ5jpxI9N1HUAAAAASUVORK5CYII=";
        this.iconeG = "";
        verificarPasta();
    }

    public String getCaminhoBanco() {
        return caminhoBanco;
    }

    public void setCaminhoBanco(String caminhoBanco) {
        this.caminhoBanco = caminhoBanco;
    }

    public String CaminhoBanco() {
        Path caminho = Paths.get("476387383");

        try {
            List<String> linhas = Files.readAllLines(caminho);
            for (String linha : linhas) {
                System.out.println(linha);
            }
        } catch (IOException e) {
            System.err.println("Erro ao ler o arquivo: " + e.getMessage());
        }

        return "";
    }

    public void verificarPasta() {
        File pasta = new File(this.vPath);
        // Verifica se a pasta existe
        if (!pasta.exists()) {
            // Tenta criar a pasta
            if (pasta.mkdirs()) {
                criarImagensPlay();
                criarImagensStop();
                criarBanco();
                criarTabela();
                criarImagensIcon();
            } else {
                System.out.println("Falha ao criar a pasta!");
            }
        } else {
            System.out.println("A pasta já existe.");
        }
    }

    public void criarImagensPlay() {
        String outputFilePath = this.vPath + "\\play48x48.png";
        try {
            // Decodifica a string Base64 para bytes
            byte[] decodedBytes = Base64.getDecoder().decode(play48);
            // Caminho do arquivo
            Path path = Paths.get(outputFilePath);

            // Escreve os bytes no arquivo PNG
            Files.write(path, decodedBytes);

            System.out.println("Imagem salva como " + outputFilePath);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void criarImagensStop() {
        String outputFilePath = this.vPath + "\\stop48x48.png";
        try {
            // Decodifica a string Base64 para bytes
            byte[] decodedBytes = Base64.getDecoder().decode(stop48);
            // Caminho do arquivo
            Path path = Paths.get(outputFilePath);

            // Escreve os bytes no arquivo PNG
            Files.write(path, decodedBytes);

            System.out.println("Imagem salva como " + outputFilePath);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void criarImagensIcon() {
        String outputFilePath = this.vPath + "\\smartwatch.png";
        try {
            // Decodifica a string Base64 para bytes
            byte[] decodedBytes = Base64.getDecoder().decode(icone);
            // Caminho do arquivo
            Path path = Paths.get(outputFilePath);

            // Escreve os bytes no arquivo PNG
            Files.write(path, decodedBytes);

            System.out.println("Imagem salva como " + outputFilePath);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void criarBanco() {
        String File_name = "C:/TimerIS/tempos.db";
        try (FileWriter writer = new FileWriter(File_name)) {
        } catch (IOException e) {
            System.err.println("Erro ao criar o arquivo CSV: " + e.getMessage());
        }
    }

    public void criarTabela() {
        String url = "jdbc:sqlite:C:/TimerIS/tempos.db";
        StringBuilder sb = new StringBuilder();
        sb.append("CREATE TABLE atividades (");
        sb.append("id	INTEGER,");
        sb.append("usuario	TEXT NOT NULL,");
        sb.append("atividade	TEXT NOT NULL,");
        sb.append("tipo	TEXT NOT NULL,");
        sb.append("outros	TEXT,");
        sb.append("cliente	TEXT,");
        sb.append("area	TEXT,");
        sb.append("observacao	TEXT, ");
        sb.append("status	TEXT NOT NULL DEFAULT 1, ");
        sb.append("data	TEXT DEFAULT (DATETIME('now', '-3 hours')), ");
        sb.append("PRIMARY KEY(id AUTOINCREMENT));");
        try (Connection connection = DriverManager.getConnection(url);
                PreparedStatement pstmt = connection.prepareStatement(sb.toString())) {
            int linhasAfetadas = pstmt.executeUpdate();
            if (linhasAfetadas > 0) {
                System.out.println("Cadastro de tempo realizado com sucesso!");
            } else {
                System.out.println("Nenhuma tempo foi inserida.");
            }
        } catch (SQLException e) {
            System.err.println("Erro SQL: " + e.getMessage());
            e.printStackTrace(); // Para depuração
        }

        String tbl_area = "CREATE TABLE area ( id INTEGER NOT NULL, Nome INTEGER, PRIMARY KEY(id AUTOINCREMENT));";
        try (Connection connection = DriverManager.getConnection(url);
                PreparedStatement pstmt = connection.prepareStatement(tbl_area)) {
            int linhasAfetadas = pstmt.executeUpdate();
            if (linhasAfetadas > 0) {
                System.out.println("Cadastro de tempo realizado com sucesso!");
            } else {
                System.out.println("Nenhuma tempo foi inserida.");
            }
        } catch (SQLException e) {
            System.err.println("Erro SQL: " + e.getMessage());
            e.printStackTrace(); // Para depuração
        }

        String tbl_cliente = "CREATE TABLE clientes ( id INTEGER NOT NULL, Nome TEXT NOT NULL, PRIMARY KEY(id AUTOINCREMENT));";
        try (Connection connection = DriverManager.getConnection(url);
                PreparedStatement pstmt = connection.prepareStatement(tbl_cliente)) {
            int linhasAfetadas = pstmt.executeUpdate();
            if (linhasAfetadas > 0) {
                System.out.println("Cadastro de tempo realizado com sucesso!");
            } else {
                System.out.println("Nenhuma tempo foi inserida.");
            }
        } catch (SQLException e) {
            System.err.println("Erro SQL: " + e.getMessage());
            e.printStackTrace(); // Para depuração
        }

        String tbl_tempos = "CREATE TABLE tempos ( id INTEGER NOT NULL, id_atividades INTEGER, dataInicio TEXT DEFAULT (DATETIME('now', '-3 hours')), dataFinal TEXT, PRIMARY KEY(id AUTOINCREMENT), CONSTRAINT FY_ATIVIDADES FOREIGN KEY(id_atividades) REFERENCES atividades(id));";
        try (Connection connection = DriverManager.getConnection(url);
                PreparedStatement pstmt = connection.prepareStatement(tbl_tempos)) {
            int linhasAfetadas = pstmt.executeUpdate();
            if (linhasAfetadas > 0) {
                System.out.println("Cadastro de tempo realizado com sucesso!");
            } else {
                System.out.println("Nenhuma tempo foi inserida.");
            }
        } catch (SQLException e) {
            System.err.println("Erro SQL: " + e.getMessage());
            e.printStackTrace(); // Para depuração
        }

        String tbl_tipoAtividade = "CREATE TABLE tipoAtividade ( id INTEGER NOT NULL, Nome TEXT NOT NULL, PRIMARY KEY(id AUTOINCREMENT) );";
        try (Connection connection = DriverManager.getConnection(url);
                PreparedStatement pstmt = connection.prepareStatement(tbl_tipoAtividade)) {
            int linhasAfetadas = pstmt.executeUpdate();
            if (linhasAfetadas > 0) {
                System.out.println("Cadastro de tempo realizado com sucesso!");
            } else {
                System.out.println("Nenhuma tempo foi inserida.");
            }
        } catch (SQLException e) {
            System.err.println("Erro SQL: " + e.getMessage());
            e.printStackTrace(); // Para depuração
        }
    }
}
/*
 C:\Users\Felipe.daSilva\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup    
    
 🔹 Dica Extra: Converter .jar para .exe
 Se quiser que o programa pareça mais profissional, você pode converter seu arquivo .jar para .exe usando ferramentas como:
 ✅ Launch4j
 ✅ JSmooth
 ✅ Jar2Exe    
    
 */
