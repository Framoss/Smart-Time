package Portable;

import java.awt.AWTException;
import java.awt.Image;
import java.awt.SystemTray;
import java.awt.Toolkit;
import java.awt.TrayIcon;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

/**
 *
 * @author felipe.dasilva
 */
public class MeuTimer {

    private Timer timer;
    private int segundos = 0;

    public void start() {
        if (timer != null) {
            System.out.println("O timer já está rodando!");
            return;
        }

        timer = new Timer();
        TimerTask tarefa = new TimerTask() {
            @Override
            public void run() {
                segundos++;
                System.out.println("Tempo: " + segundos + " segundos");
                SystemTray tray = SystemTray.getSystemTray();

                try {
                    Image image = Toolkit.getDefaultToolkit().getImage(System.getProperty("user.home") + "\\Documents\\TimerIS\\smartwatch.png");
                    TrayIcon trayIcon = new TrayIcon(image, "Notificação");
                    Random random = new Random();
                    String frase = "";
                    // Gerando um número aleatório entre 1 e 40 (pois há 40 frases)
                    int numeroAleatorio = random.nextInt(40) + 1;
                    switch (numeroAleatorio) {
                        case 1:
                            frase = "⏳ Não deixe para depois! Registre suas horas no Smart Time.";
                            break;
                        case 2:
                            frase = "🚀 O sucesso começa com um bom controle de tempo! Lance suas horas.";
                            break;
                        case 3:
                            frase = "⏰ Seu tempo vale ouro! Não se esqueça de registrar suas horas.";
                            break;
                        case 4:
                            frase = "🔍 Acompanhe seu desempenho! Faça seu lançamento no Smart Time.";
                            break;
                        case 5:
                            frase = "📅 Mantenha tudo organizado! Registre suas horas agora.";
                            break;
                        case 6:
                            frase = "📝 Um minuto agora economiza horas depois! Lance suas atividades.";
                            break;
                        case 7:
                            frase = "⏲️ Pequenos hábitos fazem a diferença! Registre seu tempo.";
                            break;
                        case 8:
                            frase = "🏆 Seu esforço conta! Registre suas horas no Smart Time.";
                            break;
                        case 9:
                            frase = "✅ Transparência é essencial! Faça seu lançamento diário.";
                            break;
                        case 10:
                            frase = "💡 Controle seu tempo, aumente sua produtividade! Registre suas horas.";
                            break;
                        case 11:
                            frase = "🔄 Mantenha o fluxo! Atualize suas horas no sistema.";
                            break;
                        case 12:
                            frase = "🎯 Seu trabalho merece reconhecimento! Registre suas horas.";
                            break;
                        case 13:
                            frase = "📊 Dados precisos = melhores decisões! Lance suas horas corretamente.";
                            break;
                        case 14:
                            frase = "🏅 Mostre seu progresso! Registre seu tempo no Smart Time.";
                            break;
                        case 15:
                            frase = "🔔 Um lembrete amigo: não esqueça de lançar suas horas!";
                            break;
                        case 16:
                            frase = "💼 Profissionalismo é manter tudo atualizado! Registre suas horas.";
                            break;
                        case 17:
                            frase = "⏱️ De grão em grão, o tempo se organiza! Lance suas atividades.";
                            break;
                        case 18:
                            frase = "🌟 Organização é a chave do sucesso! Atualize seu tempo no sistema.";
                            break;
                        case 19:
                            frase = "💬 Alguma dúvida sobre o Smart Time? Estamos aqui para ajudar!";
                            break;
                        case 20:
                            frase = "🛠️ Seu trabalho bem documentado facilita tudo! Registre suas horas.";
                            break;
                        case 21:
                            frase = "🏗️ Construímos resultados com tempo bem gerenciado! Registre suas horas.";
                            break;
                        case 22:
                            frase = "🔑 O segredo da eficiência? Manter tudo atualizado! Registre agora.";
                            break;
                        case 23:
                            frase = "🌎 Tempo bem controlado, impacto bem medido! Lance suas horas.";
                            break;
                        case 24:
                            frase = "📅 Não perca o prazo! Registre suas horas no Smart Time.";
                            break;
                        case 25:
                            frase = "⏳ Pequenos hábitos geram grandes resultados! Atualize seu tempo.";
                            break;
                        case 26:
                            frase = "🎯 Disciplina gera eficiência! Mantenha seu tempo atualizado.";
                            break;
                        case 27:
                            frase = "🏃‍♂️ Antes de encerrar o dia, registre suas atividades!";
                            break;
                        case 28:
                            frase = "🏡 Trabalhando de casa ou no escritório, registre suas horas!";
                            break;
                        case 29:
                            frase = "🔍 Cada minuto conta! Registre suas horas para um controle melhor.";
                            break;
                        case 30:
                            frase = "📋 Lançamento feito? Parabéns pela organização!";
                            break;
                        case 31:
                            frase = "🕒 O tempo bem gerenciado é um grande aliado! Registre suas horas.";
                            break;
                        case 32:
                            frase = "🛎️ Lembrete amigável: não esqueça de lançar suas horas!";
                            break;
                        case 33:
                            frase = "📊 Monitorar seu tempo ajuda a melhorar sua produtividade!";
                            break;
                        case 34:
                            frase = "🏁 Um bom controle de horas leva a melhores resultados!";
                            break;
                        case 35:
                            frase = "🌟 Seu tempo é valioso! Não deixe de registrar suas atividades.";
                            break;
                        case 36:
                            frase = "🔁 Faça do lançamento de horas um hábito diário!";
                            break;
                        case 37:
                            frase = "🧩 Um sistema bem atualizado faz toda a diferença! Registre suas horas.";
                            break;
                        case 38:
                            frase = "⏱️ Um pequeno esforço diário evita grandes problemas depois!";
                            break;
                        case 39:
                            frase = "🎉 Ótimo trabalho! Agora só falta lançar suas horas no sistema.";
                            break;
                        case 40:
                            frase = "💙 Obrigado por manter o controle atualizado! Seu esforço faz a diferença.";
                            break;
                        default:
                            frase = "Erro inesperado. Tente novamente.";
                            break;
                    }

                    tray.add(trayIcon); // Adiciona na bandeja do sistema
                    trayIcon.displayMessage("Smart Time", frase, TrayIcon.MessageType.INFO);
                    tray.remove(trayIcon);
                } catch (AWTException e) {
                    e.printStackTrace();
                }

            }
        };

        timer.scheduleAtFixedRate(tarefa, 0, 3600000); // A cada 1 segundo
        System.out.println("Timer iniciado!");
    }

    public void close() {
        if (timer != null) {
            timer.cancel();
            timer = null;
            System.out.println("Timer encerrado!");
        }
    }

    public static void main(String[] args) {
        MeuTimer meuTimer = new MeuTimer();

        meuTimer.start(); // Inicia o timer

        try {
            Thread.sleep(25000); // Espera 5 segundos

        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        meuTimer.close(); // Para o timer
    }
}
