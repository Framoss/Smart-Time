package Portable;

import java.io.IOException;
import java.sql.Connection;
import java.util.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;
import javax.swing.JOptionPane;

/**
 *
 * @author felipe.dasilva
 */
public class Transferencia {

    private String str_date_inicial;
    private String str_date_final;
    private String url;
    Connection con;
    Statement stmt;
    Map<String, String> dicionario = new HashMap<>();

    public Transferencia(Date date_inicial, Date date_final) throws SQLException {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd"); // Escolha o formato desejado

        this.str_date_inicial = sdf.format(date_inicial);
        this.str_date_final = sdf.format(date_final);
        Connection con = null;
        Statement stmt = null;
        carregarDados();
    }

    private void carregarDados() throws SQLException {
        this.url = "jdbc:sqlite:C:/TimerIS/tempos.db";
        StringBuilder sb = new StringBuilder();
        sb.append("SELECT ");
        sb.append("    atividades.id, ");
        sb.append("    atividades.usuario, ");
        sb.append("    atividades.atividade, ");
        sb.append("    atividades.tipo, ");
        sb.append("    atividades.outros, ");
        sb.append("    atividades.cliente, ");
        sb.append("    atividades.area AS sistema, ");
        sb.append("    atividades.observacao, ");
        sb.append("    atividades.status, ");
        sb.append("    atividades.data AS datacriacao, ");
        sb.append("    tempos.id AS id_tempo, ");
        sb.append("    tempos.dataInicio, ");
        sb.append("    tempos.dataFinal ");
        sb.append("FROM atividades ");
        sb.append("LEFT JOIN tempos ON (atividades.id = tempos.id_atividades) ");
        sb.append("WHERE DATE(atividades.data) BETWEEN '" + str_date_inicial + "' AND '" + str_date_final + "' and tempos.dataFinal is not null;");
        StringBuilder ole = new StringBuilder();
        try (Connection connection = DriverManager.getConnection(this.url);
                PreparedStatement statement = connection.prepareStatement(sb.toString());
                ResultSet resultSet = statement.executeQuery()) {
            
            while (resultSet.next()) {
                ole.append(" CARREGARATIVIDADES("
                        + String.valueOf(resultSet.getInt("id") + ","
                                + resultSet.getString("id_tempo") + ",'"
                                + resultSet.getString("usuario") + "','"
                                + resultSet.getString("atividade") + "','"
                                + resultSet.getString("tipo") + "','"
                                + resultSet.getString("outros") + "','"
                                + resultSet.getString("cliente") + "','"
                                + resultSet.getString("sistema") + "','"
                                + resultSet.getString("observacao") + "','"
                                + resultSet.getString("status") + "','"
                                + resultSet.getString("datacriacao") + "','"
                                + resultSet.getString("dataInicio") + "','"
                                + resultSet.getString("dataFinal")) + "');\n");
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Para fins de depuração
            JOptionPane.showMessageDialog(null, "Erro ao carregar dados", "Erro", JOptionPane.ERROR_MESSAGE);
        }

        String url = "jdbc:oracle:thin:@//7583672k-app.db.int.ck:1876/";
        String user = "7675_878";
        String password = "564ffg";

        try {
            // Estabelecendo a conexão
            con = DriverManager.getConnection(url, user, password);
            stmt = con.createStatement();
            String sql = "BEGIN " + ole.toString() + " END;";
            System.out.println("Executando: " + sql);

            stmt.executeUpdate(sql);
            System.out.println("Execução bem-sucedida!");
            JOptionPane.showMessageDialog(null, "Dados enviados para o banco ", "Integração concluída", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException e) {
            System.err.println("Erro na conexão ou execução da SQL: " + e.getMessage());
            e.printStackTrace();
        } finally {
            // Fechando recursos
            try {
                if (stmt != null) {
                    stmt.close();
                }
                if (con != null) {
                    con.close();
                }
            } catch (SQLException ex) {
                System.err.println("Erro ao fechar conexão: " + ex.getMessage());
            }
        }

    }
}
