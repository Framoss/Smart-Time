package main;


import com.formdev.flatlaf.intellijthemes.FlatDarkFlatIJTheme;
import froms.JFrameAtividades;

public class TimerIS {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        FlatDarkFlatIJTheme.setup();
        JFrameAtividades form = new JFrameAtividades();
        form.setVisible(true);
        form.setTitle("Nova atividade.");
        
    }
    
}
